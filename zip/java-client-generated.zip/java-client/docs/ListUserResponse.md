
# ListUserResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**users** | [**List&lt;User&gt;**](User.md) |  |  [optional]
**nextPageToken** | **String** |  |  [optional]



